cd MCreator20211
./mcreator.sh
